module.exports = function () {
    var module = {};

    module.pipeline_state = {
        name: "single_state",
        cur_stage_idx: 0,
        //pipe_line - to generate 1-5 images using only text prompt and also generate images for various social media sites
        pipe_info:{label:"gen_img_for_social_media_pipe", id:"gen_img_for_social_media"}, 
        user_state:{
            info:{
                id:"JAYKANIDAN",
                // path of the file with which we are going to ctrl the image generation 
                // attachments: [{url:"./share_vol/data_io/inp/infinity_white.png", 
                //               filename:'00000.png', width: 512, height: 512, content_type: 'image/png'}],
              
            },
            gpu_state:{} //Not sure whether it is required. Probably future use
        },
        stage_state:[{
            // Stage 0: Generate the image - setting the parameters to generate image.
            // gen_img(theme, prompt, op_fld, control_type=None, ctrl_img_path=None, n_prompt="", height=512, width=512,seed=-1, num_images=1,                                   safety_checker=None, collect_cache=True)

            // theme - choose required theme to be used for img gen
            // prompt - give the text prompt for img genenation
            // num_images: number of images to be generated. max uptil 5 we can generate, avoid while using with seed value.
            // seed - can be set only when you want a particular (same) type of image to be generated, else better comment the line 
            // n_prompt: if we have particular details to be set in negative prompt we can give it prompt value here.
            // op_fld - path of the output where the image is stored.
              config:{ 
                 
                theme:{val : "people", label: "Theme", show: true, type:"default"}, 
                prompt:{val : "RAW photo, 25 y.o woman in sitting in mdeidation pose wearing a red tshirt and yoga pants, look at me, calm, peaceful, suttle smile, dslr, soft lighting, high quality, film grain, Fujifilm XT ", 
                           label: "prompt", show: true, type: "default"}, 
            //  num_images: {val:1 , lable: "num_images", show: false, type: "defalut"}, 
            //  seed: { val:2358633856 , label: "seed_val", show: false, type: "default"},
            //  n_prompt: {val: "(worst quality:1.4), (low quality:1.4), (semi-realistic anime illustration 3d rendering drawing), blurry, grainy ",label:                                  "n_prompt", show: true, type: "default"},
                op_fld:{val : "./img/", show: false, type:"path"},
            },
            gpu_state:{ 
              function: "gen_one_img", // Name of the function to call
              stage_status:"in_queue", // "pre_stage" "in_queue", "gpu_triggered", "error", "complete"
              stage_progress: 0, // Percentage of task completion
              output:['https://tmpfiles.org/1900371/generated123.mp4',
                      'https://tmpfiles.org/1900371/generated123.mp4'],
            }},{
            // Stage 1: Generate the different dimensions for different social media format - we are calling inpaint to fill in the extra space outside the image                generated.
            // gen_inpaint_filler(theme, prompt, img_path, imgfmt_list, op_fld)
            config:{ 
                theme:{val : "people", label: "Theme", show: true, type:"default"},
                prompt:{val : "Waterfall background in the wild", label: "Prompt", show: true, type:"default"},
                img_path:{val : {stg_idx:0, type:"array2idx", idx:0}, show: false, type:"wrkflw_link"},
                imgfmt_list:{val:"insta_square, insta_potrait, twit_instream, whatsapp_status, fb_post",
                        label: "Image Format", show: true, type:"array"},
                op_fld:{val : "./logo_list/", show: false, type:"path"}
            },
            gpu_state:{ 
                function: "gen_inpaint_filler", // Name of the function to call
                stage_status:"in_queue", // "pre_stage" "in_queue", "gpu_triggered", "error", "complete"
                stage_progress: 0, // Percentage of task completion
            }},
        ],
    }
    return module;
};